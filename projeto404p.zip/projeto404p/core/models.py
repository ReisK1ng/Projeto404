from django.db import models
from datetime import datetime

class Pedido(models.Model):
    nome_cliente = models.CharField(max_length=100)
    endereco = models.CharField(max_length=255)
    itens = models.TextField()  # lista de itens em string
    observacoes = models.TextField(blank=True, null=True)
    criado_em = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Pedido #{self.id} - {self.nome_cliente}"


class Avaliacao(models.Model):
    NOTAS = [
        (1, '1'),
        (2, '2'),
        (3, '3'),
        (4, '4'),
        (5, '5'),
    ]
    nome_cliente = models.CharField(max_length=100)
    comentario = models.TextField()
    nota = models.IntegerField(choices=NOTAS)
    data = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.nome_cliente} - Nota {self.nota}"

    data = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.nome_cliente} - Nota: {self.nota}"

