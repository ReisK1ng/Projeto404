// Carrinho de Compras
const carrinho = [];
const toastPedido = new bootstrap.Toast(document.getElementById('toastPedido'));

// Adicionar itens ao carrinho
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', () => {
        const nome = button.getAttribute('data-name');
        const preco = parseFloat(button.getAttribute('data-price'));
        
        carrinho.push({ nome, preco });
        atualizarCarrinho();
        
        // Mostra toast
        toastPedido.show();
    });
});

// Atualiza o carrinho
function atualizarCarrinho() {
    const lista = document.getElementById('listaPedidos');
    const total = document.getElementById('totalCarrinho');
    const contador = document.getElementById('contadorCarrinho');
    
    // Limpa a lista
    lista.innerHTML = '';
    
    // Adiciona itens
    let soma = 0;
    carrinho.forEach((item, index) => {
        const li = document.createElement('li');
        li.className = 'list-group-item';
        li.innerHTML = `
            ${item.nome} 
            <span class="text-danger fw-bold">R$ ${item.preco.toFixed(2)}</span>
            <span class="badge bg-danger" onclick="removerItem(${index})">X</span>
        `;
        lista.appendChild(li);
        soma += item.preco;
    });
    
    // Atualiza total e contador
    total.textContent = `R$ ${soma.toFixed(2)}`;
    contador.textContent = carrinho.length;
}

// Remove item do carrinho
window.removerItem = (index) => {
    carrinho.splice(index, 1);
    atualizarCarrinho();
};

// Finalizar pedido
document.getElementById('finalizarPedido').addEventListener('click', () => {
    if (carrinho.length === 0) {
        alert('Adicione itens ao carrinho primeiro!');
        return;
    }
    
    const numero = '5511999999999'; 
    const texto = `Pedido:\n${carrinho.map(item => `- ${item.nome}: R$ ${item.preco.toFixed(2)}`).join('\n')}\n\nTotal: R$ ${document.getElementById('totalCarrinho').textContent}`;
    
    window.open(`https://wa.me/${numero}?text=${encodeURIComponent(texto)}`);
    carrinho.length = 0;
    atualizarCarrinho();
    bootstrap.Modal.getInstance(document.getElementById('carrinhoModal')).hide();
});
