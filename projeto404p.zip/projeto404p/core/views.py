from django.shortcuts import render, redirect, get_object_or_404
from .models import Pedido
from .forms import PedidoForm
from .forms import AvaliacaoForm
from .models import Avaliacao
from core.models import Avaliacao


def home(request):
    return render(request, 'index.html')

def listar_pedidos(request):
    pedidos = Pedido.objects.order_by('-criado_em')
    return render(request, 'meus_pedidos.html', {'pedidos': pedidos})

def criar_pedido(request):
    if request.method == 'POST':
        form = PedidoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('meus_pedidos')
    else:
        form = PedidoForm()
    return render(request, 'criar_pedido.html', {'form': form})

def editar_pedido(request, id):
    pedido = get_object_or_404(Pedido, id=id)
    form = PedidoForm(request.POST or None, instance=pedido)
    if form.is_valid():
        form.save()
        return redirect('meus_pedidos')
    return render(request, 'editar_pedido.html', {'form': form})

def deletar_pedido(request, id):
    pedido = get_object_or_404(Pedido, id=id)
    if request.method == 'POST':
        pedido.delete()
        return redirect('meus_pedidos')
    return render(request, 'deletar_pedido.html', {'pedido': pedido})


def avaliacoes(request):
    if request.method == 'POST':
        form = AvaliacaoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('avaliacoes')
    else:
        form = AvaliacaoForm()

    comentarios = Avaliacao.objects.order_by('-data') 

    return render(request, 'avaliacoes.html', {
        'form': form,
        'comentarios': comentarios
    })


def contar_notas_maximas(avaliacoes, index=0, contador=0):
    if index >= len(avaliacoes):
        return contador
    if avaliacoes[index].nota == 5:
        contador += 1
    return contar_notas_maximas(avaliacoes, index + 1, contador)

def avaliacoes(request):
    # Processa envio do formulário
    if request.method == 'POST':
        form = AvaliacaoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('avaliacoes')
    else:
        form = AvaliacaoForm()

    ordenar = request.GET.get('ordenar', 'cronologico')  # padrão cronológico
    avaliacoes_qs = list(Avaliacao.objects.all())

    # Ordenação
    if ordenar == 'cronologico':
        avaliacoes_qs.sort(key=lambda x: x.data)
    elif ordenar == 'inverso':
        avaliacoes_qs.sort(key=lambda x: x.data, reverse=True)
    elif ordenar == 'nota_desc':
        avaliacoes_qs = quick_sort(avaliacoes_qs, key=lambda x: x.nota, reverse=True)
    elif ordenar == 'nota_asc':
        avaliacoes_qs = bubble_sort(avaliacoes_qs, key=lambda x: x.nota)
    else:
        avaliacoes_qs.sort(key=lambda x: x.data)

    qtd_notas_maximas = contar_notas_maximas(avaliacoes_qs)
    media_notas = calcular_media_recursiva(avaliacoes_qs)

    return render(request, 'avaliacoes.html', {
        'comentarios': avaliacoes_qs,
        'ordenar': ordenar,
        'qtd_notas_maximas': qtd_notas_maximas,
        'media_notas': media_notas,
        'form': form
    })




# Bubble Sort (ordenação crescente)
def bubble_sort(lista, key=lambda x: x):
    n = len(lista)
    for i in range(n):
        for j in range(0, n-i-1):
            if key(lista[j]) > key(lista[j+1]):
                lista[j], lista[j+1] = lista[j+1], lista[j]
    return lista

# Quick Sort (ordenação decrescente)
def quick_sort(lista, key=lambda x: x, reverse=False):
    if len(lista) <= 1:
        return lista
    pivot = lista[0]
    if reverse:
        left = [x for x in lista[1:] if key(x) > key(pivot)]
        right = [x for x in lista[1:] if key(x) <= key(pivot)]
    else:
        left = [x for x in lista[1:] if key(x) < key(pivot)]
        right = [x for x in lista[1:] if key(x) >= key(pivot)]
    return quick_sort(left, key, reverse) + [pivot] + quick_sort(right, key, reverse)

def calcular_media_recursiva(avaliacoes, index=0, soma=0):
    if index == len(avaliacoes):
        if len(avaliacoes) == 0:
            return 0  # evita divisão por zero
        media = soma / len(avaliacoes)
        return min(max(media, 1), 5)  # garante que fique entre 1 e 5
    return calcular_media_recursiva(avaliacoes, index + 1, soma + avaliacoes[index].nota)
