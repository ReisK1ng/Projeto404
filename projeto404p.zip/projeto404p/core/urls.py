from django.urls import path
from . import views

urlpatterns = [
    path('', views.listar_pedidos, name='meus_pedidos'),          # /pedidos/
    path('novo/', views.criar_pedido, name='criar_pedido'),       # /pedidos/novo/
    path('<int:id>/editar/', views.editar_pedido, name='editar_pedido'),   # /pedidos/123/editar/
    path('<int:id>/deletar/', views.deletar_pedido, name='deletar_pedido'), # /pedidos/123/deletar/
    path('avaliacoes/', views.avaliacoes, name='avaliacoes'),
]