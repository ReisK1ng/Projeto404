from django import forms
from .models import Pedido
from .models import Avaliacao

class PedidoForm(forms.ModelForm):
    class Meta:
        model = Pedido
        fields = ['nome_cliente', 'endereco', 'itens', 'observacoes']


class AvaliacaoForm(forms.ModelForm):
    class Meta:
        model = Avaliacao
        fields = ['nome_cliente', 'comentario', 'nota']
        widgets = {
            'comentario': forms.Textarea(attrs={'rows': 3}),
            'nota': forms.Select()
        }